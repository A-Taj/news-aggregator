import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  searchKeyword: '',
  filters: {
    category: '',
    from: '',
    to: '',
    source:'NewsAPI.org',
  },
  articles: [],
  loading: false,
  error: null,
};

const newsSlice = createSlice({
  name: 'news',
  initialState,
  reducers: {
    setSearchKeyword: (state, action) => {
      state.searchKeyword = action.payload;
    },
    setFilters: (state, action) => {
      state.filters = { ...state.filters, ...action.payload };
    },
    fetchArticlesStart: (state) => {
      state.loading = true;
      state.error = null;
    },
    fetchArticlesSuccess: (state, action) => {
      state.loading = false;
      state.articles = action.payload;
    },
    fetchArticlesFailure: (state, action) => {
      state.loading = false;
      state.error = action.payload;
    },
  },
});

export const {
  setSearchKeyword,
  setFilters,
  fetchArticlesStart,
  fetchArticlesSuccess,
  fetchArticlesFailure,
} = newsSlice.actions;

export default newsSlice.reducer;
