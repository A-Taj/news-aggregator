import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
  fetchArticlesStart,
  fetchArticlesSuccess,
  fetchArticlesFailure,
} from '../features/newsSlice';

const useFetchArticles = () => {
  const dispatch = useDispatch();
  const { searchKeyword, filters } = useSelector((state) => state.news);
 
  let url;

  useEffect(() => {
    const fetchArticles = async () => {
      dispatch(fetchArticlesStart());
      const apiKey = '73c3488c03e84317b8b87e53a6e71c60'; // Replace with your API key
      const { category, from, to, source} = filters;
      const Category = category.toLowerCase();
      console.log("source",source);

      if(source === "NewsAPI.org"){
        url = `https://newsapi.org/v2/top-headlines?q=${searchKeyword}&category=${Category}&from=${from}&to=${to}&language=en&apiKey=${apiKey}`;
      }
      if(source === "The Guardian"){
        url = `https://content.guardianapis.com/search?q=${searchKeyword}&tag=${Category}/${Category}&from-date=${from}&to-date=${to}&api-key=test`;
      }
    

      try {
        const response = await fetch(url);
        const data = await response.json();
        console.log("data",data);
        if (response.ok) {
          console.log("data.articles",data);
          if(source === "NewsAPI.org"){
            dispatch(fetchArticlesSuccess(data.articles));
          }
          if(source === "The Guardian"){
            dispatch(fetchArticlesSuccess(data.response?.results));
          }
        } else {
          dispatch(fetchArticlesFailure(data.message || 'Failed to fetch articles.'));
        }
      } catch (error) {
        dispatch(fetchArticlesFailure(error.message));
      }
    };

    fetchArticles();
  }, [url, dispatch, searchKeyword, filters]);

  return useSelector((state) => state.news);
};

export default useFetchArticles;
