import React from 'react';
import Header from './components/header';
import MainContainer from './components/mainContainer';
import Footer from './components/footer';

const App = () => {
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      <MainContainer />
      <Footer />
    </div>
  );
};

export default App;
