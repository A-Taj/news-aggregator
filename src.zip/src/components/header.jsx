import React from 'react';
import SearchBar from './SearchBar';
import NavBar from './NavBar';

const Header = () => {
  return (
    <header className="flex flex-col lg:flex-row justify-between items-center p-4 bg-blue-500 shadow-md">
      <div className="text-white text-2xl font-bold mb-4 lg:mb-0">News Aggregator</div>
      <div className="flex flex-col lg:flex-row items-center gap-4 lg:gap-8 w-full lg:w-auto">
        <SearchBar />
        <NavBar />
      </div>
    </header>
  );
};

export default Header;
