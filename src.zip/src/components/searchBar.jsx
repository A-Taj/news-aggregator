import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { setSearchKeyword } from '../features/newsSlice';

const SearchBar = () => {
  const [query, setQuery] = useState('');
  const dispatch = useDispatch();

  const handleSearch = () => {
    dispatch(setSearchKeyword(query));
  };

  return (
    <div className="flex flex-col sm:flex-row items-center gap-4 sm:gap-6 w-full sm:w-auto">
      <input
        type="text"
        className="p-2 w-full sm:w-64 md:w-96 border border-gray-300 rounded-l-full"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        placeholder="Search news..."
      />
      <button 
        onClick={handleSearch}
        className="mt-2 sm:mt-0 bg-blue-600 hover:bg-blue-700 text-white p-2 rounded-r-full w-full sm:w-auto transition-all"
      >
        Search
      </button>
    </div>
  );
};

export default SearchBar;
