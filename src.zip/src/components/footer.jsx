const Footer = () => (
    <footer className="p-4 bg-blue-500 text-white text-center">
      <p>&copy; 2024 NewsAggregator. All Rights Reserved.</p>
    </footer>
  );
  
  export default Footer;
  