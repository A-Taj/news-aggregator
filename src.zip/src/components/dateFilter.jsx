import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { setFilters } from '../features/newsSlice';

const DateFilter = ({ label }) => {
  const dispatch = useDispatch();
  const { filters } = useSelector((state) => state.news);

  const handleFilterChange = (key, value) => {
    console.log("dateval",value)
    console.log("key",key)
    dispatch(setFilters({ [key]: value }));
  };

  // Derive the filter key based on the label
  const filterKey = label.toLowerCase(); // Convert "From" or "To" to "from" or "to"

  return (
    <div className="mb-4">
      <label className="block mb-2">{label}</label>
      <input
        type="date"
        className="w-full p-2 border rounded-md"
        value={filters[filterKey] || ''} // Use filters.from or filters.to dynamically
        onChange={(e) => handleFilterChange(filterKey, e.target.value)} // Pass the derived key
      />
    </div>
  );
};

export default DateFilter;
