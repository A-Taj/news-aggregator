import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { setFilters } from '../features/newsSlice';

const CategoryFilter = () => {
  const dispatch = useDispatch();
  const { filters } = useSelector((state) => state.news);

  const handleFilterChange = (key, value) => {
    dispatch(setFilters({ [key]: value }));
  };
  
  return(
    <div className="mb-4">
      <label className="block mb-2">Category</label>
      <select className="w-full p-2 border rounded-md" value={filters.category}
          onChange={(e) => handleFilterChange('category', e.target.value)}>
        <option value="">All</option>
        <option>Technology</option>
        <option>Health</option>
        <option>Sports</option>
        <option>Entertainment</option>
        <option>Business</option>
        <option>Science</option>
        <option>Sports</option>
      </select>
    </div>
  );
}
  
export default CategoryFilter;  