import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { setFilters } from '../features/newsSlice';

const SourceFilter = () => {

  const dispatch = useDispatch();
  const { filters } = useSelector((state) => state.news);

  const handleFilterChange = (key, value) => {
    dispatch(setFilters({ [key]: value }));
  };

  return (
    <div className="mb-4">
      <label className="block mb-2">Source</label>
      <select className="w-full p-2 border rounded-md" value={filters.source}
          onChange={(e) => handleFilterChange('source', e.target.value)}>
        <option>NewsAPI.org</option>
        <option>OpenNews</option>
        <option>The Guardian</option>
        <option>New York Times</option>
      </select>
    </div>
  );
} 
  export default SourceFilter;
  