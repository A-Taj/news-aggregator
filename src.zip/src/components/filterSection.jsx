import DateFilter from './dateFilter';
import CategoryFilter from './categoryFilter';
import SourceFilter from './sourceFilter';

const FilterSection = () => (
  <div className="w-full lg:w-1/4 p-4">
    <label className="block mb-2 font-bold">Filter</label>
    <SourceFilter />
    <CategoryFilter />
    <DateFilter label="From" />
    <DateFilter label="To" />
  </div>
);

export default FilterSection;
