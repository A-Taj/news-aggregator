import React, { useState } from 'react';

const NavBar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <nav className="relative w-full lg:w-auto">
      {/* Hamburger Menu */}
      <div className="lg:hidden flex items-center">
        <button
          onClick={toggleMenu}
          className="text-white hover:text-blue-300 transition duration-300"
          aria-label="Menu"
        >
          <svg
            className="w-8 h-8"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16"></path>
          </svg>
        </button>
      </div>

      {/* Navigation Links */}
      <div
        className={`absolute lg:static top-full left-0 right-0 bg-blue-600 lg:bg-transparent lg:flex lg:space-x-6 lg:items-center ${
          isMenuOpen ? 'block' : 'hidden'
        } transition-all duration-300`}
      >
        <a href="#" className="block text-white hover:bg-blue-700 px-6 py-3 lg:px-4 lg:py-2 rounded-md text-center">
          Home
        </a>
        <a href="#" className="block text-white hover:bg-blue-700 px-6 py-3 lg:px-4 lg:py-2 rounded-md text-center">
          About
        </a>
        <a href="#" className="block text-white hover:bg-blue-700 px-6 py-3 lg:px-4 lg:py-2 rounded-md text-center">
          Contact
        </a>
      </div>
    </nav>
  );
};

export default NavBar;
