import React from 'react';
import FilterSection from './filterSection';
import ArticleSection from './articleSection';

const MainContainer = () => {
  return (
    <div className="flex flex-col lg:flex-row">
      <FilterSection />
      <ArticleSection />
    </div>
  );
};

export default MainContainer;
